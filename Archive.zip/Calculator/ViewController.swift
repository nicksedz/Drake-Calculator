

import UIKit
import AVFoundation
import QuartzCore
class ViewController: UIViewController

{
    var brain = CalculatorBrain()
    let youthebest = "you-the-best"
    let chef = "chef-curry"
    let back = "back-to-back"
//  var sound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("oh-man", ofType: "wav")!)
    
    
    @IBOutlet weak var display: UILabel!
    
    var userIsInTheMiddleOfTypingANumber = false
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return UIStatusBarStyle.LightContent
    }
    
    let images = [
        UIImage(named: "drake_bg.jpg")!,
        UIImage(named: "drake_bg.jpg")!
    ]
    
    var index = 0
    
    let animationDuration: NSTimeInterval = 0.5
    let switchingInterval: NSTimeInterval = 5

    
    
    func animateImageView() {
        CATransaction.begin()
        
        CATransaction.setAnimationDuration(animationDuration)
        CATransaction.setCompletionBlock {
            let delay = dispatch_time(DISPATCH_TIME_NOW, Int64(self.switchingInterval * NSTimeInterval(NSEC_PER_SEC)))
            dispatch_after(delay, dispatch_get_main_queue()) {
                self.animateImageView()
            }
        }
        
        let transition = CATransition()
        transition.type = kCATransitionFade
        /*
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromRight
        */
        imageView.layer.addAnimation(transition, forKey: kCATransition)
        imageView.image = images[index]
        
        CATransaction.commit()
        
        index = index < images.count - 1 ? index + 1 : 0
    }
    
        var imageView:UIImageView!
        func setupBackgroundImage() {
        imageView = UIImageView(frame: self.view.frame)
        imageView.contentMode = UIViewContentMode.ScaleAspectFill
        self.view.addSubview(imageView)
        
        imageView.autoresizingMask = [.FlexibleWidth,
            .FlexibleHeight];
       
        
    }

    
    // Grab the path, make sure to add it to your project!
    var baseSound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("ohman", ofType: "wav")!)
    var audioPlayer = AVAudioPlayer()
    

    let sounds = ["worldtoher","girlstour","Jumpman","backtoback","CountingMoney","runningthruthe","Woes","thatshigo","prenup","openup","ItaghtYou","onething","thugforher","ohman"]

    override func viewDidLoad() {
        
        setupBackgroundImage()
        
        imageView.image = images[index++]
// z.position for grey box
        imageView.layer.zPosition = -2
        animateImageView()
        

        display.layer.zPosition = 1
        
        player = AVAudioPlayer()
//        let text = UITextField(frame: self.view.frame)
//        
//        text.keyboardType = UIKeyboardType.NumbersAndPunctuation
//        self.view.addSubview(text)
   
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOfURL: baseSound)
            audioPlayer.prepareToPlay()
        } catch {        }
        
        
        
        
        for child in self.view.subviews {
            
            if let button = child as? UIButton {
                
                
                button.titleLabel!.font =  UIFont(name: "Helvetica-Bold", size: 40)
                if button.titleLabel?.text == "AC"{
                    button.titleLabel!.font =  UIFont(name: "Helvetica-Bold", size: 30)
                }
                button.layer.zPosition = 1
                
                
                
                
                //BUTTON COLOR **
                button.tintColor = UIColor.whiteColor()
                
                //BUTTON OPACITY **
                button.alpha = 0.9
                
                //BUTTON PUSHED COLOR **
                button.setTitleColor(UIColor.blueColor(), forState: UIControlState.Highlighted)
                
                //ADJUST BUTTON SIZE **
                button.transform = CGAffineTransformMakeScale(0.7, 0.7)
                
                //ADJUST BUTTON SPRING **
                UIView.animateWithDuration(2.0,
                    delay: 0,
                    usingSpringWithDamping: 0.1,
                    initialSpringVelocity: 3,
                    options: UIViewAnimationOptions.AllowUserInteraction,
                    animations: {
                    button.transform = CGAffineTransformIdentity
                    }, completion: nil)
                
                //BUTTON BLUR **
//                let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Light)
//                let blurView = UIVisualEffectView(effect: blurEffect)
//                blurView.frame = button.bounds
//                button.addSubview(blurView)
                
                
                


               //RANDOM BUTTON COLOR **
//             let colors = getColorAccentForColor(randomBrightColor(), count: 4)
//                                button.titleLabel?.set = colors[0]
//                
//                button.titleLabel?.textColor = UIColor.redColor()
//
//                UIView.transitionWithView(button, duration: 5.0, options: UIViewAnimationOptions.TransitionCrossDissolve, animations: {
//                    button.titleLabel?.textColor = colors[2]
//                    }, completion:nil)

 
                
                
//                button.setTitleColor(randomBrightColor(), forState: .Normal)
//                button.titleLabel?.textColor = UIColor.redColor()
//
//                UIView.animateWithDuration(1, delay: 0.0, options:[UIViewAnimationOptions.Repeat,           UIViewAnimationOptions.Autoreverse], animations: {
//                    button.setTitleColor(randomBrightColor(), forState: .Normal)
//                    button.setTitleColor(randomBrightColor(), forState: .Normal)
//
//                    }, completion: nil)
                
                
//                button.backgroundColor = UIColor.grayColor()
//                button.layer.shadowColor = UIColor.whiteColor().CGColor
//                button.layer.shadowOpacity = 1.0
//                button.layer.shadowOffset = CGSizeMake(0, 3)
//                button.layer.shadowRadius = 5

            }
          
            
        }
        
        
//        if let image = UIImage(named: "drake.jpg") {
//            view.backgroundColor = UIColor(patternImage: image)
//            
//            
//        } else {
//            print("There was no such image as background.jpg")
//        }
//        
       
    }
    
    @IBAction func appendDigit(sender: UIButton) {
        
      
        var sound = "Woes"

        let digit = sender.currentTitle!
        if userIsInTheMiddleOfTypingANumber {
            display.text = display.text! + digit
            
            var soundName = ""
            
            if (Int(digit) != nil) {
                sound = sounds[Int(digit)!]

            } else {
                sound = sounds[10]

            }
        
            
            do {
                if ( audioPlayer.playing) {
                    audioPlayer.stop()
                }
                baseSound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource(sound, ofType: "wav")!)
                
                audioPlayer = try AVAudioPlayer(contentsOfURL: baseSound)
                audioPlayer.prepareToPlay()
                audioPlayer.play()
                
            } catch {
                
            }
            

            
        } else {
            display.text = digit
            userIsInTheMiddleOfTypingANumber = true
        }
    }
    
    var player:AVAudioPlayer!
    
    @IBAction func operate(sender: UIButton) {
        let operation = sender.currentTitle!
        var soundName = ""
        
        if operation == "+" {
            
            soundName = "I-feel-blessed"
            
        } else if operation == "−" {
            
            soundName = youthebest
            
        } else if operation == "×" {
            
            soundName = chef
            
        } else if operation == "AC" {
            
            soundName = back
            
        } else if operation == "=" {
            
            soundName = "Jumpman"
            
        }
    
    
        
        if let soundURL = NSBundle.mainBundle().URLForResource(soundName, withExtension: "wav") {
            var mySound: SystemSoundID = 0
            AudioServicesCreateSystemSoundID(soundURL, &mySound)
            // Play
            AudioServicesPlaySystemSound(mySound);
        }
        
        
        if userIsInTheMiddleOfTypingANumber {
            enter()
        }
        if let result = brain.performOperation(operation) {
            displayValue = result
        } else {
            displayValue = 0
        }
    }
    
    func enter() {
        userIsInTheMiddleOfTypingANumber = false
        if let result = brain.pushOperand(displayValue) {
            displayValue = result
        } else {
            displayValue = 0
        }
    }

    @IBAction func getResult(sender: UIButton) {
        
        if userIsInTheMiddleOfTypingANumber {
            userIsInTheMiddleOfTypingANumber = false
            brain.pushOperand(displayValue)
        }
        if let result = brain.getResult() {
            displayValue = result
        } else {
            displayValue = 0
        }
        
        
    }
    
    
    
    @IBAction func clear(sender: UIButton) {
        brain.clear()
        displayValue = 0
    }
    
    var displayValue: Double {
        get {
            return NSNumberFormatter().numberFromString(display.text!)!.doubleValue
        }
        set {
            display.text = "\(newValue)"
            userIsInTheMiddleOfTypingANumber = false
        }
    }
    
}

