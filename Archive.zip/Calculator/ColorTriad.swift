//
//  ColorTriad.swift
//  Starfield
//
//  Created by Evan Bacon on 10/19/15.
//  Copyright © 2015 Hesham Amiri. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit
func getColorTriadForColor(color:UIColor) -> [UIColor] {
    
    var h: CGFloat = 0
    var s: CGFloat = 0
    var b: CGFloat = 0
    var a: CGFloat = 0

    color.getHue(&h, saturation: &s, brightness: &b, alpha: &a)
    var triad1 = h + (1.0/3.0)
    if triad1 >= 1.0 {
        triad1 = triad1 - 1
    }
    let triA = UIColor(
        hue: triad1,
        saturation: s,
        brightness: b,
        alpha: a)
    
    var triad2 = h + (2.0/3.0)
    if triad2 >= 1.0 {
        triad2 = triad2 - 1
    }
    
    let triB = UIColor(
        hue: triad2,
        saturation: s,
        brightness: b,
        alpha: a)


    return [color,triA,triB]
}


func randomDarkColor() -> SKColor {
    let hue = CGFloat( 1.0 );  //  Blue

//    let hue = CGFloat( Double(arc4random()) % 256.0 / 256.0 );  //  0.0 to 1.0
    let saturation = CGFloat( Double(arc4random()) % 128.0 / 256.0 );  //  0.5 to 1.0, away from white
    let brightness = CGFloat( Double(arc4random()) % 128.0 / 256.0 );  //  0.5 to 1.0, away from black
    
    return SKColor(hue: hue, saturation: saturation, brightness: brightness, alpha: 1.0)
    
}


func spriteFromText(text: String) -> SKTexture {
    
    let textLayer = CATextLayer()
    textLayer.frame = CGRectMake(0, 0, 40, 40)
    
//    // 2
//    var string = ""
//    for _ in 1...20 {
//        string += "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce auctor arcu quis velit congue dictum. "
//    }
    
    textLayer.string = text
    
//    let fontSize = CGFloat(50);
//    // 3
//    let fontName: CFStringRef = "Noteworthy-Light"
//    textLayer.font = CTFontCreateWithName(fontName, fontSize, nil)
    
    // 4
    textLayer.foregroundColor = UIColor.darkGrayColor().CGColor
    textLayer.wrapped = true
    textLayer.alignmentMode = kCAAlignmentCenter
    textLayer.contentsScale = UIScreen.mainScreen().scale

    return SKTexture(image: imageFromLayer(textLayer))
}

func imageFromLayer(layer: CALayer) -> UIImage
{
    UIGraphicsBeginImageContext(layer.frame.size);
    
    
    layer.renderInContext(UIGraphicsGetCurrentContext()!);
    let outputImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return outputImage;
}


func getColorAccentForColor(color:UIColor, count: Int) -> [UIColor] {
    let interval = CGFloat(6.0)
    var h: CGFloat = 0
    var s: CGFloat = 0
    var b: CGFloat = 0
    var a: CGFloat = 0
    color.getHue(&h, saturation: &s, brightness: &b, alpha: &a)

    
    var colors:[UIColor] = []
    for i in 0...count - 1  {
        
        var triad1 = h + (CGFloat(i)/interval)
        if triad1 >= 1.0 {
            triad1 = triad1 - 1
        }
        let triA = UIColor(
            hue: triad1,
            saturation: s,
            brightness: b,
            alpha: a)
        
        colors.append(triA)
    }
   
    return colors
}

func randomBrightColor() -> UIColor {
    let hue = CGFloat( Double(arc4random()) % 256.0 / 256.0 );  //  0.0 to 1.0
    let saturation = CGFloat( Double(arc4random()) % 128.0 / 256.0 ) + 0.5;  //  0.5 to 1.0, away from white
    let brightness = CGFloat( Double(arc4random()) % 128.0 / 256.0 ) + 0.5;  //  0.5 to 1.0, away from black
    
    return UIColor(hue: hue, saturation: saturation, brightness: brightness, alpha: 1.0)
    
}


func randomSolidHueColor() -> UIColor {
    let randomHue:CGFloat = randomCGFloat()
//    print(randomHue)
//    var randomGreen:CGFloat = CGFloat(drand48())
    
//    var randomBlue:CGFloat = CGFloat(drand48())
    
    return UIColor(hue: randomHue, saturation: 1.0, brightness: 1.0, alpha: 1.0)
    
}
func randomCGFloat() -> CGFloat {
    return CGFloat(arc4random()) / CGFloat(UInt32.max)
}
