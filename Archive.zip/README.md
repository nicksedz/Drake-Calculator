# ios-simple-calculator
A simple calculator implemented by Swift language

This project has been updated to Xcode 7.0.1
